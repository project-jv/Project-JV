/* sendpraat.h */
/* Paul Boersma, September 27, 2000 */

#ifdef __cplusplus
	extern "C" {
#endif

char *sendpraat (void *display, const char *programName, long timeOut, const char *text);

#ifdef __cplusplus
	}
#endif

/* End of file sendpraat.h */
